var c = 5;
var h = [3, 2, 5, 7, 6, 1];
h.splice(3, 0, 3746)
console.log(h)